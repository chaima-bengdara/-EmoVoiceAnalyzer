from django.conf import settings
from django.shortcuts import render
from joblib import load
import numpy as np
import os
from django.http import HttpResponse

def classify_voice(request):
    prediction = None

    if request.method == 'POST' and request.FILES['voiceFile']:
        voice_file = request.FILES['voiceFile']

        # Construct the model path using BASE_DIR
        model_path = os.path.join(settings.BASE_DIR, 'savedmodels', 'modellstm.joblib')

        # Check if the file exists before loading
        if os.path.exists(model_path):
            lstm_model = load(model_path)

            # Assuming your model expects a feature vector as input
            # Replace this with actual feature extraction logic
            feature_vector = extract_feature_from_voice(voice_file)

            # Perform the prediction
            lstm_prediction = lstm_model.predict(np.expand_dims(feature_vector, axis=0))

            # Map the prediction to male or female (adjust as per your model's output)
            gender_prediction = "Male" if lstm_prediction == 0 else "Female"

            # Create a dictionary with predictions
            prediction = {'gender_prediction': gender_prediction}
        else:
            print(f"File not found: {model_path}")

    return render(request, 'index.html', {'prediction': prediction})

def extract_feature_from_voice(voice_file):
    # Implement logic to extract features from the voice file
    # Replace this with actual feature extraction logic
    # For example, you might want to use a library like librosa for audio feature extraction.
    # Here, I'm assuming a placeholder function that returns a random feature vector.
    feature_vector = np.random.randn(128, 128)
    return feature_vector
