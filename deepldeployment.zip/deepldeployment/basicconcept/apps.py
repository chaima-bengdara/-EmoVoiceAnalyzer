from django.apps import AppConfig


class BasicconceptConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'basicconcept'
